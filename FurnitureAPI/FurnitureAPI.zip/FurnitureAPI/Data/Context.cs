﻿using FurnitureAPI.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace FurnitureAPI.Data
{
    public class Context: DbContext
    {
        public DbSet<UserEntity> Users { get; set; }
        public DbSet<UnconfirmedUserEntity> UnconfirmedUsers { get; set; }
        public DbSet<FurnitureTypeEntity> FurnitureTypes { get; set; }
        public DbSet<FurnitureEntity> Furnitures { get; set; }

        public DbSet<UserForgotPasswordKeyEntity> UserForgotPasswordKeys { get; set; }

        public Context(DbContextOptions<Context> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<UserEntity>()
            .HasIndex(u => u.Email)
            .IsUnique();

            builder.Entity<UnconfirmedUserEntity>()
            .HasIndex(u => u.Email)
            .IsUnique();

            builder.Entity<UserForgotPasswordKeyEntity>()
                .HasIndex(up => up.UserId)
                .IsUnique();
        }
    }
}
