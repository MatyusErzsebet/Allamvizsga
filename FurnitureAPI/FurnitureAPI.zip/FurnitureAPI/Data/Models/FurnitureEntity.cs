﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FurnitureAPI.Data.Models
{
    public class FurnitureEntity
    {
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Price { get; set; }

        [Required]
        [ForeignKey(nameof(FurnitureType))]
        public int FurnitureTypeId { get; set; }
        public FurnitureTypeEntity FurnitureType { get; set;}
        

    }
}
