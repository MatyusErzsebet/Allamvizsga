﻿using AutoMapper;
using FurnitureAPI.Data.Models;
using FurnitureAPI.Models;
using FurnitureAPI.Services;
using FurnitureAPI.Services.ServiceResponses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FurnitureAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;

        public UsersController(IUserService userService, IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        [Route("SendRegistrationCode")]
        [HttpPost]
        public async Task<IActionResult> SendRegistrationCode([FromBody] UnconfirmedUser UserModel)
        {
            try
            {
                var user = _mapper.Map<UnconfirmedUserEntity>(UserModel);

                var result = await _userService.SendRegistrationCode(user);

                switch (result)
                {
                    case UserServiceResponses.BADREQUEST: return BadRequest("User can't be null");
                    case UserServiceResponses.ERROR: return StatusCode(500, "Unconfirmed user could not be added");
                    case UserServiceResponses.SUCCESS: return StatusCode(201, "Unconfirmed user added");
                    case UserServiceResponses.USERALREADYEXISTS: return StatusCode(409, "User already exists");
                    case UserServiceResponses.EMAILNOTSENT: return StatusCode(500, "Email could not be sent.");
                    default : return StatusCode(500, "Unknown service response");
                }
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [Route("Registration")]
        [HttpGet]
        public async Task<IActionResult> Registration([FromQuery(Name = "email")] string email, [FromQuery(Name = "code")] string validationKey )
        {
            try
            {
         
                var result = await _userService.RegisterUser(email, validationKey);

                switch (result)
                {
                    case UserServiceResponses.BADREQUEST:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = (int)HttpStatusCode.BadRequest,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>Validation key mismatch</div></body></html>"
                        };
                    case UserServiceResponses.ERROR:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = 500,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>Email could not be verified</div></body></html>"
                        };
                    case UserServiceResponses.SUCCESS:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = 201,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:green;'>Email verified</div></body></html>"
                        };
                    case UserServiceResponses.NOTFOUND:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = 404,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>User with the given email not found or the validation key has expired</div></body></html>"
                        };
                    case UserServiceResponses.EMAIL_NOT_FOUND:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = (int)HttpStatusCode.BadRequest,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>Email required</div></body></html>"
                        };
                    case UserServiceResponses.VALIDATION_KEY_NOT_FOUND:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = (int)HttpStatusCode.BadRequest,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>Validation code required</div></body></html>"
                        };
                    default:
                        return new ContentResult
                        {
                            ContentType = "text/html",
                            StatusCode = 500,
                            Content = "<html><body><div style='font-size: 32px; text-align:center; color:red;'>Unknown server error</div></body></html>"
                        };
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            try
            {
                var result = await _userService.Login(loginModel.Email, loginModel.Password);
                switch (result)
                {
                    case UserServiceResponses.BADREQUEST: return BadRequest("Password mismatch");
                    case UserServiceResponses.NOTFOUND: return NotFound("User with given email not found");
                    case UserServiceResponses.SUCCESS: return StatusCode(201, "Login succeeded");
                    default: return StatusCode(500, "Unknown service response");
                }
            }

            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpPost]
        [Route("SendForgotPasswordKey")]
        public async Task<IActionResult> SendForgotPasswordKey(SendForgotPasswordKeyModel model)
        {
            try
            { 
                var result = await _userService.SendForgotPasswordKey(model.Email);
                switch (result)
                {
                    case UserServiceResponses.BADREQUEST: return BadRequest("Email required");
                    case UserServiceResponses.NOTFOUND: return NotFound("User with given email not found");
                    case UserServiceResponses.SUCCESS: return StatusCode(201, "Password change email sent successfully");
                    case UserServiceResponses.EMAILNOTSENT: return StatusCode(500, "Email could not be sent.");
                    default: return StatusCode(500, "Unknown service response");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("VerifyForgotPasswordKey")]
        public async Task<IActionResult> VerifyForgotPasswordKey(VerifyForgotPasswordKeyModel model)
        {
            try
            {
                var result = await _userService.VerifyForgotPasswordKey(model.Email, model.Key);
                switch (result)
                {
                    case UserServiceResponses.BADREQUEST: return BadRequest("Key mismatch");
                    case UserServiceResponses.NOTFOUND: return NotFound("User with given email not found");
                    case UserServiceResponses.SUCCESS: return StatusCode(201, "Password change key verified successfully");
                    case UserServiceResponses.EMAIL_NOT_FOUND: return StatusCode(500, "Email is required");
                    case UserServiceResponses.VALIDATION_KEY_NOT_FOUND: return StatusCode(400, "Password change key is required");
                    case UserServiceResponses.FORGOTPASSWORDNOTSETTOUSER: return StatusCode(404, "Password change was not required by user");
                    default: return StatusCode(500, "Unknown service response");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

    }
}
