﻿using FurnitureAPI.Data.Models;
using FurnitureAPI.Services.ServiceResponses;
using System.Threading.Tasks;

namespace FurnitureAPI.Services
{
    public interface IUserService
    {
        public Task<UserServiceResponses> SendRegistrationCode(UnconfirmedUserEntity user);
        public Task<UserServiceResponses> RegisterUser(string email, string validationKey);
        public Task<UserServiceResponses> Login(string email, string password);
        public Task<UserServiceResponses> SendForgotPasswordKey(string email);

    }
}
