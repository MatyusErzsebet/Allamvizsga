﻿using FurnitureAPI.Data;
using FurnitureAPI.Data.Models;
using FurnitureAPI.Services.ServiceResponses;
using FurnitureAPI.Utils;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace FurnitureAPI.Services
{
    public class UserService : IUserService
    {
        private readonly Context _context;

        public UserService(Context context)
        {
            _context = context;
        }

        public async Task<UserServiceResponses> RegisterUser(string email, string validationKey)
        {
            if (email == null)
                return UserServiceResponses.EMAIL_NOT_FOUND;

            if (validationKey == null)
                return UserServiceResponses.VALIDATION_KEY_NOT_FOUND;

            var unconfirmedUser = await _context.UnconfirmedUsers.FirstOrDefaultAsync(uu => string.Equals(uu.Email, email));
            if (unconfirmedUser == null)
                return UserServiceResponses.NOTFOUND;

            if (!string.Equals(unconfirmedUser.ValidationKey, validationKey))
                return UserServiceResponses.BADREQUEST;

           
            _context.Users.Add(new UserEntity { Email = unconfirmedUser.Email, BirthDate = unconfirmedUser.BirthDate,
                FirstName = unconfirmedUser.FirstName, LastName = unconfirmedUser.LastName, Password = unconfirmedUser.Password, Role = "User" });

            try
            {
                await _context.SaveChangesAsync();
                return UserServiceResponses.SUCCESS;
            }
            catch(Exception ex)
            {
                return UserServiceResponses.ERROR;
            }
            
        }

        public async Task<UserServiceResponses> SendRegistrationCode(UnconfirmedUserEntity user)
        {
            if (user == null)
                return UserServiceResponses.BADREQUEST;

            var result2 = await _context.Users.FirstOrDefaultAsync(u => string.Equals(u.Email, user.Email));
            if (result2 != null)
                return UserServiceResponses.USERALREADYEXISTS;

            var result = await _context.UnconfirmedUsers.FirstOrDefaultAsync(uu => string.Equals(uu.Email, user.Email));

            if(result != null)
            {
                _context.UnconfirmedUsers.Remove(result);             
            }

            string validationKey;
            UnconfirmedUserEntity SearchedUser;
            do {
                validationKey = ValidationKeyGenerator.GenerateValidationKey();
                SearchedUser = await _context.UnconfirmedUsers.FirstOrDefaultAsync(u => string.Equals(u.ValidationKey, validationKey));
            }
            while (SearchedUser != null);

            user.ValidationKey = validationKey;
            user.ValidationKeyExpirationDate = DateTime.Now.AddMinutes(10);
            user.Role = "User";
            _context.UnconfirmedUsers.Add(user);

            try
            {
                await _context.SaveChangesAsync();
                var link = "https://localhost:44316/api/Users/Registration?email=" + user.Email + "&code=" + user.ValidationKey;
                if(MyEmailSender.SendMail(user.Email, "Registration", "Use this link to verify your user: <a href = " + link + "> link </a>. The verification link is available for 10 minutes.") == false)
                {
                    return UserServiceResponses.EMAILNOTSENT;
                }
                return UserServiceResponses.SUCCESS;
            }
            catch
            {
                return UserServiceResponses.ERROR;
            }
        }

        public async Task<UserServiceResponses> Login(string email, string password)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => string.Equals(u.Email, email));
            if (user == null)
                return UserServiceResponses.NOTFOUND;

            if (string.Equals(user.Password, password))
                return UserServiceResponses.SUCCESS;

            return UserServiceResponses.BADREQUEST;
        }

        public async Task<UserServiceResponses> SendForgotPasswordKey(string email)
        {
            if (email == null)
                return UserServiceResponses.BADREQUEST;

            var user = await _context.Users.FirstOrDefaultAsync(u => string.Equals(u.Email, email));
            if (user == null)
                return UserServiceResponses.NOTFOUND;

            string changeKey = ValidationKeyGenerator.GenerateForgotPasswordKey();

            _context.UserForgotPasswordKeys.Add(new UserForgotPasswordKeyEntity { UserId = user.Id, ChangeKey = changeKey, KeyExpirationDate = DateTime.Now.AddMinutes(10) });

            try
            {
                await _context.SaveChangesAsync();
                if(MyEmailSender.SendMail(user.Email, "Password change", "Your forgot password key is " + changeKey + " and is active for 10 minutes.") == false){
                    return UserServiceResponses.EMAILNOTSENT;
                }
                return UserServiceResponses.SUCCESS;
            }
            catch(Exception ex)
            {
                return UserServiceResponses.ERROR;
            }

        }

        
    }
}