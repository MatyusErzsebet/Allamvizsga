﻿namespace FurnitureAPI.Models
{
    public class VerifyForgotPasswordKeyModel
    {
    }
}
