﻿using System.ComponentModel.DataAnnotations;

namespace FurnitureAPI.Models
{
    public class SendPassowrdChangeKeyModel
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Not an email address")]
        public string Email { get; set; }
    }
}
