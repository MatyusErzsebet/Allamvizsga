﻿namespace FurnitureAPI.Models
{
    public class UserTokenModel
    {
        public UserModel User { get; set; }
        public string Token { get; set; }
    }
}
