﻿namespace FurnitureAPI.Services.ServiceResponses
{
    public enum FurnitureServiceResponses
    {
        SUCCESS = 200,
        BADREQUEST = 400,
        ERROR = 500,
        NOTFOUND = 404
    }
}
