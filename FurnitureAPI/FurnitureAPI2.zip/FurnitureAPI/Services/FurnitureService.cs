﻿using FurnitureAPI.Data;
using FurnitureAPI.Data.Models;
using FurnitureAPI.Models;
using FurnitureAPI.Services.ServiceResponses;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FurnitureAPI.Services
{
    public class FurnitureService : IFurnitureService
    {
        private readonly Context _context;
        public FurnitureService(Context context) {
            _context = context;
        }

        public async Task<FurnitureTypeEntity> GetFurnitureTypeById(int id)
        {
            return await _context.FurnitureTypes.FirstOrDefaultAsync(ft => ft.Id == id);
        }

        public async Task<FurnitureServiceResponses> AddFurniture(FurnitureEntity furniture)
        {
            var furntureType = await GetFurnitureTypeById(furniture.FurnitureTypeId);

            if (furntureType == null)
                return FurnitureServiceResponses.NOTFOUND;

            
            _context.Furnitures.Add(furniture);

            try
            {
                await _context.SaveChangesAsync();
                return FurnitureServiceResponses.SUCCESS;  
            }
            catch
            {
                return FurnitureServiceResponses.ERROR;
            }
        }


        public async Task<List<FurnitureWithRatingAverageEntity>> GetFurnitures()
        {
            var list = await _context.Furnitures.Where(f => f.IsDeleted == false).ToListAsync();
            List<FurnitureWithRatingAverageEntity> result = new();

            foreach(var f in list)
            {
                var furnitureType = await GetFurnitureTypeById(f.FurnitureTypeId);
                var reviewsForFurnitureCt = _context.Reviews.Where(r => r.FurnitureId == f.Id).Count();
                float ratingAverage;
                if (reviewsForFurnitureCt == 0)
                    ratingAverage = 0;
                else
                    ratingAverage = (float)_context.Reviews.Average(r => r.Rating);
                
                result.Add(new FurnitureWithRatingAverageEntity { AvailableQuantity = f.AvailableQuantity, Description = f.Description, FurnitureTypeId = f.FurnitureTypeId, Id = f.Id, ImageUrl = f.ImageUrl, Name = f.Name, Price = f.Price, Size = f.Size, FurnitureTypeName = furnitureType.Name, RatingAverage = ratingAverage });
            }

            return result;
        }

        public async Task<FurnitureEntity> GetFurnitureById(int id)
        {
            return await _context.Furnitures.FirstOrDefaultAsync(f => f.Id == id);
        }

        public async Task<FurnitureServiceResponses> UpdateFurnitre(UpdateFurnitureModel model, FurnitureEntity furniture)
        {
            furniture.AvailableQuantity = model.AvailableQuantity;
            furniture.IsDeleted = model.IsDeleted;
            furniture.FurnitureTypeId = model.FurnitureTypeId;
            furniture.Price = model.Price;
            furniture.Description = model.Description;
            furniture.Name = model.Name;
            furniture.Size = model.Size;

            _context.Entry(furniture).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return FurnitureServiceResponses.SUCCESS;
            }
            catch
            {
                return FurnitureServiceResponses.ERROR;
            }

        }

        public async Task<FurnitureWithReviewsEntity> GetFurnitureWithReviewsById(int id)
        {
            var furniture = await GetFurnitureById(id);
            if (furniture == null)
                return null;

            var furnitureType = await GetFurnitureTypeById(furniture.Id);
            List<ReviewWithUserNamesEntity> reviews = new();
            foreach(var r in await _context.Reviews.ToListAsync())
            {
                var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == r.UserId);
                reviews.Add(new ReviewWithUserNamesEntity { Comment = r.Comment, FurnitureId = r.FurnitureId, FurnitureName = furniture.Name, Id = r.Id, Rating = r.Rating, UserId = r.UserId, UserName = user.FirstName + " " + user.LastName });
            }

            return new FurnitureWithReviewsEntity { AvailableQuantity = furniture.AvailableQuantity, Description = furniture.Description, Name = furniture.Name, FurnitureTypeId = furniture.FurnitureTypeId, Id = furniture.Id, ImageUrl = furniture.ImageUrl, IsDeleted = furniture.IsDeleted, Price = furniture.Price, Size = furniture.Size, FurnitureTypeName = furnitureType.Name, Reviews = reviews};
        }
    }
}
