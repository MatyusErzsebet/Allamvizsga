﻿using AutoMapper;
using FurnitureAPI.Data.Models;
using FurnitureAPI.Models;
using FurnitureAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FurnitureAPI.Controllers { 
    [Route("api/[controller]")]
    [ApiController]
    public class PurchasesController : ControllerBase
    {
        private readonly IPurchaseService _PurchaseService;
        private readonly IUserService _userService;
        private IMapper _mapper;

        public PurchasesController(IPurchaseService PurchaseService, IUserService userService, IMapper mapper)
        {
            _PurchaseService = PurchaseService;
            _userService = userService;
            _mapper = mapper;
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> AddPurchase(AddPurchaseModel addPurchaseModel)
        {
            try
            {

                StringValues values;
                var res = Request.Headers.TryGetValue("Token", out values);
                var user = await _userService.GetUserFromToken(values);


                var PurchaseList = _mapper.Map<List<PurchaseEntity>>(addPurchaseModel.Purchases);
                var result = await _PurchaseService.AddPurchases(PurchaseList, user.Id, addPurchaseModel.Address);

                if (result == Services.ServiceResponses.PurchaseServiceResponses.FURNITURENOTFOUND)
                    return NotFound( "One furniture from the list was not found");


                if (result == Services.ServiceResponses.PurchaseServiceResponses.EXCEPTION)
                    return StatusCode(500, "Purchase could not be added");

                return StatusCode(201, "Purchase added");

            }

            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /*
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPurchases()
        {
            try
            {
                var result = _mapper.Map<List<AdminsPurchaseResult>>(await _PurchaseService.GetPurchases());
                return StatusCode(200, new BackendResponse<List<AdminsPurchaseResult>>(200, result));
            }
            catch(Exception ex)
            {
                return StatusCode(500, new BackendResponse<object>(500, ex.Message));
            }
        }
        */
    }
}
